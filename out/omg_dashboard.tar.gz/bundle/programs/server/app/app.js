var require = meteorInstall({"lib":{"collections":{"tradedb.js":function(){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// lib/collections/tradedb.js                                               //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
TradesDB = new Mongo.Collection('trades');                                  // 1
CandlesDB = new Mongo.Collection('candles');                                // 2
//////////////////////////////////////////////////////////////////////////////

}}},"server":{"getData.js":["meteor/meteor",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// server/getData.js                                                        //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                            //
getCandlesFurl = function getCandlesFurl() {                                // 3
  HTTP.call('GET', 'http://webrates.truefx.com/rates/connect.html', {       // 4
    params: {                                                               // 5
      "c": "EUR/USD"                                                        // 6
    }                                                                       // 5
  }, function (error, response) {                                           // 4
    if (error) {                                                            // 10
      console.log(error);                                                   // 11
    } else {                                                                // 12
      var value = response.content.substring(7, 15) * 10000 % 10;           // 13
      var curTime = Math.round(+new Date() / 1000);                         // 14
                                                                            //
      CandlesDB.insert({                                                    // 16
        curr: "EUR/USD",                                                    // 17
        curTime: curTime,                                                   // 18
        val: value,                                                         // 19
        type: null                                                          // 20
      });                                                                   // 16
                                                                            //
      if (CandlesDB.find().count() > 10000) {                               // 23
        var tmp = CandlesDB.find().fetch()[0]._id;                          // 24
        CandlesDB.remove({ _id: tmp });                                     // 25
      }                                                                     // 26
    }                                                                       // 27
  });                                                                       // 28
};                                                                          // 30
                                                                            //
getTrades = function getTrades() {                                          // 32
  Trades.changes().run(function (err, result) {                             // 33
    result.each(Meteor.bindEnvironment(function (err, row) {                // 34
      Users.filter({ id: row.new_val.user_id }).run(function (err, res) {   // 35
        res.each(function (err, nres) {                                     // 36
          var name = "Jon Doe";                                             // 37
          if (nres.facebook) {                                              // 38
            name = nres.facebook.name;                                      // 39
          }                                                                 // 40
          var money = String(row.new_val.outcome);                          // 41
          var mclass = "";                                                  // 42
          var curr = "€";                                                   // 43
          var resultstr = "trade";                                          // 44
          var final = " from " + String(row.new_val.amount) + curr;         // 45
          var cm = ~~(new Date().valueOf() / 60000);                        // 46
          var type = row.new_val.type;                                      // 47
          var curTime = Math.round(+new Date() / 1000);                     // 48
                                                                            //
          if (row.new_val.outcome == null) {                                // 51
            mclass = "event-bet";                                           // 52
            money = String(row.new_val.amount);                             // 53
            final = " on " + row.new_val.type;                              // 54
          } else if (row.new_val.outcome > 0) {                             // 55
            mclass = "event-win";                                           // 57
            resultstr = "win";                                              // 58
            type = null;                                                    // 59
          } else {                                                          // 60
            resultstr = "lost";                                             // 62
            mclass = "event-loss";                                          // 63
            type = null;                                                    // 64
          }                                                                 // 65
                                                                            //
          money = money.replace('-', '');                                   // 67
          TradesDB.insert({                                                 // 68
            money: money,                                                   // 69
            mclass: mclass,                                                 // 70
            curr: curr,                                                     // 71
            resultstr: resultstr,                                           // 72
            final: final,                                                   // 73
            name: name,                                                     // 74
            cm: cm,                                                         // 75
            curTime: curTime,                                               // 76
            type: type                                                      // 77
          });                                                               // 68
                                                                            //
          if (row.new_val.outcome == null) {                                // 80
            Meteor.setTimeout(function () {                                 // 81
              CandlesDB.update({ curTime: curTime }, {                      // 82
                $set: {                                                     // 85
                  curr: "EUR/USD",                                          // 86
                  type: row.new_val.type                                    // 87
                }                                                           // 85
              });                                                           // 84
            }, 1000);                                                       // 90
          }                                                                 // 91
        });                                                                 // 92
      });                                                                   // 93
    }));                                                                    // 94
  });                                                                       // 95
};                                                                          // 96
//////////////////////////////////////////////////////////////////////////////

}],"methods.js":function(){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// server/methods.js                                                        //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
if (Meteor.isServer) {                                                      // 1
  Trades = new Rethink.Table('trade');                                      // 2
  Users = new Rethink.Table('user');                                        // 3
                                                                            //
  Meteor.publish('trades', function () {                                    // 5
    this.ready();                                                           // 6
    return TradesDB.find();                                                 // 7
  });                                                                       // 8
                                                                            //
  Meteor.publish('candles', function () {                                   // 11
    this.ready();                                                           // 12
    return CandlesDB.find();                                                // 13
  });                                                                       // 14
                                                                            //
  Meteor.methods({                                                          // 16
                                                                            //
    getTrades: function () {                                                // 18
      function getTrades() {                                                // 18
        var out = Trades.count().run();                                     // 19
        return out;                                                         // 20
      }                                                                     // 21
                                                                            //
      return getTrades;                                                     // 18
    }()                                                                     // 18
  });                                                                       // 16
}                                                                           // 23
//////////////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// server/main.js                                                           //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                            //
Meteor.startup(function () {                                                // 3
  Meteor.setInterval(getCandlesFurl, 1000);                                 // 4
  getTrades();                                                              // 5
  //Code to run at Startup                                                  // 6
});                                                                         // 7
//////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/collections/tradedb.js");
require("./server/getData.js");
require("./server/methods.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
