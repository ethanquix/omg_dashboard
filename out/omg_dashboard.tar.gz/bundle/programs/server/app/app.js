var require = meteorInstall({"lib":{"collections":{"tradedb.js":function(){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// lib/collections/tradedb.js                                               //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
TradesDB = new Mongo.Collection('trades');                                  // 1
//////////////////////////////////////////////////////////////////////////////

}}},"server":{"methods.js":function(){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// server/methods.js                                                        //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
if (Meteor.isServer) {                                                      // 1
  Trades = new Rethink.Table('trade');                                      // 2
  Users = new Rethink.Table('user');                                        // 3
  //TradesDB = new Mongo.Collection('trades');                              // 4
  var r = Rethink.r;                                                        // 5
                                                                            //
  Meteor.publish('trades', function (mid) {                                 // 8
    var self = this;                                                        // 9
    var name = "Jon Doe";                                                   // 10
                                                                            //
    Trades.changes().run(function (err, result) {                           // 12
      result.each(Meteor.bindEnvironment(function (err, row) {              // 13
                                                                            //
        Users.filter({ id: row.new_val.user_id }).run(function (err, res) {
          res.each(function (err, nres) {                                   // 16
            if (nres.facebook) {                                            // 17
              name = nres.facebook.name;                                    // 18
            }                                                               // 19
            var money = String(row.new_val.outcome);                        // 20
            var mclass = "";                                                // 21
            var curr = "€";                                                 // 22
            var resultstr = "bet";                                          // 23
            var final = " from " + String(row.new_val.amount) + curr;       // 24
            var cm = ~~(new Date().valueOf() / 60000);                      // 25
                                                                            //
            if (row.new_val.outcome == null) {                              // 27
              mclass = "event-bet";                                         // 28
              money = String(row.new_val.amount);                           // 29
              final = " on " + row.new_val.type;                            // 30
              prelast = String(row.new_val.type);                           // 31
            } else if (row.new_val.outcome > 0) {                           // 32
              mclass = "event-win";                                         // 34
              resultstr = "win";                                            // 35
            } else {                                                        // 36
              resultstr = "lost";                                           // 38
              mclass = "event-loss";                                        // 39
            }                                                               // 40
                                                                            //
            money = money.replace('-', '');                                 // 42
                                                                            //
            TradesDB.insert({                                               // 44
              money: money,                                                 // 45
              mclass: mclass,                                               // 46
              curr: curr,                                                   // 47
              resultstr: resultstr,                                         // 48
              final: final,                                                 // 49
              name: name,                                                   // 50
              mid: mid,                                                     // 51
              cm: cm                                                        // 52
            });                                                             // 44
          });                                                               // 54
        });                                                                 // 55
        //self.added('trades', String(i), out);                             // 56
      }));                                                                  // 57
    });                                                                     // 58
                                                                            //
    self.ready();                                                           // 60
    return TradesDB.find({ mid: mid });                                     // 61
  });                                                                       // 62
                                                                            //
  Meteor.methods({                                                          // 64
                                                                            //
    getTrades: function () {                                                // 66
      function getTrades() {                                                // 66
        var out = Trades.count().run();                                     // 67
        return out;                                                         // 68
      }                                                                     // 69
                                                                            //
      return getTrades;                                                     // 66
    }()                                                                     // 66
  });                                                                       // 64
}                                                                           // 71
//////////////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// server/main.js                                                           //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                            //
Meteor.startup(function () {                                                // 3
  //Code to run at Startup                                                  // 4
});                                                                         // 5
//////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/collections/tradedb.js");
require("./server/methods.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
