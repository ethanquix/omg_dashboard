var require = meteorInstall({"lib":{"collections":{"tradedb.js":function(){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// lib/collections/tradedb.js                                               //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
TradesDB = new Mongo.Collection('trades');                                  // 1
CandlesDB = new Mongo.Collection('candles');                                // 2
//////////////////////////////////////////////////////////////////////////////

}}},"server":{"getData.js":["meteor/meteor",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// server/getData.js                                                        //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                            //
getCandlesFurl = function getCandlesFurl() {                                // 3
  HTTP.call('GET', 'http://webrates.truefx.com/rates/connect.html', {       // 4
    params: {                                                               // 5
      "c": "EUR/USD"                                                        // 6
    }                                                                       // 5
  }, function (error, response) {                                           // 4
    if (error) {                                                            // 10
      console.log(error);                                                   // 11
    } else {                                                                // 12
      var value = response.content.substring(7, 15) * 10000 % 10;           // 13
      var curTime = Math.round(+new Date() / 1000);                         // 14
                                                                            //
      CandlesDB.insert({                                                    // 16
        curr: "EUR/USD",                                                    // 17
        curTime: curTime,                                                   // 18
        val: value,                                                         // 19
        type: null                                                          // 20
      });                                                                   // 16
    }                                                                       // 22
  });                                                                       // 23
};                                                                          // 25
                                                                            //
getTrades = function getTrades() {                                          // 27
  Trades.changes().run(function (err, result) {                             // 28
    result.each(Meteor.bindEnvironment(function (err, row) {                // 29
      Users.filter({ id: row.new_val.user_id }).run(function (err, res) {   // 30
        res.each(function (err, nres) {                                     // 31
          var name = "Jon Doe";                                             // 32
          if (nres.facebook) {                                              // 33
            name = nres.facebook.name;                                      // 34
          }                                                                 // 35
          var money = String(row.new_val.outcome);                          // 36
          var mclass = "";                                                  // 37
          var curr = "€";                                                   // 38
          var resultstr = "trade";                                          // 39
          var final = " from " + String(row.new_val.amount) + curr;         // 40
          var cm = ~~(new Date().valueOf() / 60000);                        // 41
          var type = row.new_val.type;                                      // 42
          var curTime = Math.round(+new Date() / 1000);                     // 43
                                                                            //
          if (row.new_val.outcome == null) {                                // 46
            mclass = "event-bet";                                           // 47
            money = String(row.new_val.amount);                             // 48
            final = " on " + row.new_val.type;                              // 49
          } else if (row.new_val.outcome > 0) {                             // 50
            mclass = "event-win";                                           // 52
            resultstr = "win";                                              // 53
            type = null;                                                    // 54
          } else {                                                          // 55
            resultstr = "lost";                                             // 57
            mclass = "event-loss";                                          // 58
            type = null;                                                    // 59
          }                                                                 // 60
                                                                            //
          money = money.replace('-', '');                                   // 62
          TradesDB.insert({                                                 // 63
            money: money,                                                   // 64
            mclass: mclass,                                                 // 65
            curr: curr,                                                     // 66
            resultstr: resultstr,                                           // 67
            final: final,                                                   // 68
            name: name,                                                     // 69
            cm: cm,                                                         // 70
            curTime: curTime,                                               // 71
            type: type                                                      // 72
          });                                                               // 63
                                                                            //
          if (row.new_val.outcome == null) {                                // 75
            Meteor.setTimeout(function () {                                 // 76
              CandlesDB.update({ curTime: curTime }, {                      // 77
                $set: {                                                     // 80
                  curr: "EUR/USD",                                          // 81
                  type: row.new_val.type                                    // 82
                }                                                           // 80
              });                                                           // 79
            }, 1000);                                                       // 85
          }                                                                 // 86
        });                                                                 // 87
      });                                                                   // 88
    }));                                                                    // 89
  });                                                                       // 90
};                                                                          // 91
//////////////////////////////////////////////////////////////////////////////

}],"methods.js":function(){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// server/methods.js                                                        //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
if (Meteor.isServer) {                                                      // 1
  Trades = new Rethink.Table('trade');                                      // 2
  Users = new Rethink.Table('user');                                        // 3
                                                                            //
  Meteor.publish('trades', function () {                                    // 5
    this.ready();                                                           // 6
    return TradesDB.find();                                                 // 7
  });                                                                       // 8
                                                                            //
  Meteor.publish('candles', function () {                                   // 11
    this.ready();                                                           // 12
    return CandlesDB.find();                                                // 13
  });                                                                       // 14
                                                                            //
  Meteor.methods({                                                          // 16
                                                                            //
    getTrades: function () {                                                // 18
      function getTrades() {                                                // 18
        var out = Trades.count().run();                                     // 19
        return out;                                                         // 20
      }                                                                     // 21
                                                                            //
      return getTrades;                                                     // 18
    }()                                                                     // 18
  });                                                                       // 16
}                                                                           // 23
//////////////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// server/main.js                                                           //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                            //
Meteor.startup(function () {                                                // 3
  Meteor.setInterval(getCandlesFurl, 1000);                                 // 4
  getTrades();                                                              // 5
  //Code to run at Startup                                                  // 6
});                                                                         // 7
//////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/collections/tradedb.js");
require("./server/getData.js");
require("./server/methods.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
