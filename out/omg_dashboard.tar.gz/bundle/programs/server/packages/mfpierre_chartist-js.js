(function () {

/* Package-scope variables */
var Chartist;



/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['mfpierre:chartist-js'] = {}, {
  Chartist: Chartist
});

})();
